========================================================================
    CONSOLE APPLICATION : ShortcutIcon Project Overview
========================================================================

AppWizard has created this ShortcutIcon application for you.

The sole purpose of this EXE is to contain the Icon that is used by the desktop
shortcut.  Because there is no other EXE associated with this project this was 
created so that the WIX based installer has something to hold the Icon.

/////////////////////////////////////////////////////////////////////////////
